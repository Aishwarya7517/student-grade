# Student Grade Calculator
Task-2: Student Grade Calculator
<br/>
Language: Core Java
<br/>
IDE: Netbeans
<br/>
My Task is to create the Student based Calculator, which calculates their Total Marks, Average Percentage & their corresponding Grade also.Calculate the grade of a student based on their marks. This task meets all of the requirements and has been thoroughly tested.
<br/>
<h1>Demo Video: </h1>






https://github.com/deblinaroy11/CodSoft_Task_2/assets/137715845/4f21ad16-771c-4b21-8d5f-58ad469a987e



<br/>
<h1>Snapshot: </h1>


![github_1](https://github.com/deblinaroy11/CodSoft_Task_2/assets/137715845/18d943cd-7407-480b-bcd3-b9e97ff1f580)
![github_2](https://github.com/deblinaroy11/CodSoft_Task_2/assets/137715845/3dd97ff3-5b14-4007-b999-66fabcb38fa3)
![github_3](https://github.com/deblinaroy11/CodSoft_Task_2/assets/137715845/d2a89597-1258-4c7c-8153-306990328254)
![github_4](https://github.com/deblinaroy11/CodSoft_Task_2/assets/137715845/e6b0e55d-347a-4506-ab07-3f5578838790)
![github_5](https://github.com/deblinaroy11/CodSoft_Task_2/assets/137715845/40c8a397-eb14-44c8-9df2-c7a571944686)
